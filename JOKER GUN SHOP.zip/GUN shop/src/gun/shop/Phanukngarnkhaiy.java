/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gun.shop;

import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;







/**
 *
 * @author bukke
 */
public class Phanukngarnkhaiy extends javax.swing.JFrame {

    /**
     * Creates new form Phanukngarnkhaiy
     */
    public Phanukngarnkhaiy() {
        initComponents();
        SelectPhanukngarnkhaiy();
    }
Connection Con= null;
Statement St = null;
ResultSet Rs = null;
public void SelectPhanukngarnkhaiy()
{
    try{
    Con = DriverManager.getConnection("jdbc:derby://localhost:1527/JokerGunShop","User1","1234");
    St = Con.createStatement();
    Rs = St.executeQuery("Select *  from User1.PhanukngarnTb");
    TaTahlarngPN.setModel(DbUtils.resultSetToTableModel(Rs));
    }catch(Exception ex)
    {
        ex.printStackTrace();
    }    
}

    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        SuePhanukngarn = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        IDPhanukngarn = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        LahutPhanukngarn = new javax.swing.JTextField();
        PhedPhanukngarn = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        BunthuekPN = new javax.swing.JButton();
        KeaKhaiPN = new javax.swing.JButton();
        ClearPN = new javax.swing.JButton();
        LobPN = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TaTahlarngPN = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 102, 102));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("Saysettha MX", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("ຊື່:");

        SuePhanukngarn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        SuePhanukngarn.setForeground(new java.awt.Color(255, 102, 102));
        SuePhanukngarn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SuePhanukngarnActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Saysettha MX", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("ID ພະນັກງານ:");

        IDPhanukngarn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        IDPhanukngarn.setForeground(new java.awt.Color(255, 102, 102));

        jLabel5.setFont(new java.awt.Font("Saysettha MX", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("ລະຫັດ:");

        LahutPhanukngarn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        LahutPhanukngarn.setForeground(new java.awt.Color(255, 102, 102));
        LahutPhanukngarn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LahutPhanukngarnActionPerformed(evt);
            }
        });

        PhedPhanukngarn.setFont(new java.awt.Font("Saysettha MX", 1, 18)); // NOI18N
        PhedPhanukngarn.setForeground(new java.awt.Color(255, 102, 102));
        PhedPhanukngarn.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ຊາຍ", "ຍິງ" }));
        PhedPhanukngarn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PhedPhanukngarnActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Saysettha MX", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("ຕາຕະລາງລາຍຊື່ພະນັກງານຂາຍ");

        BunthuekPN.setFont(new java.awt.Font("Saysettha MX", 1, 18)); // NOI18N
        BunthuekPN.setForeground(new java.awt.Color(255, 102, 102));
        BunthuekPN.setText("ບັນທືກ");
        BunthuekPN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BunthuekPNMouseClicked(evt);
            }
        });

        KeaKhaiPN.setFont(new java.awt.Font("Saysettha MX", 1, 18)); // NOI18N
        KeaKhaiPN.setForeground(new java.awt.Color(255, 102, 102));
        KeaKhaiPN.setText("ແກ້ໄຂ");
        KeaKhaiPN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                KeaKhaiPNMouseClicked(evt);
            }
        });

        ClearPN.setFont(new java.awt.Font("Saysettha MX", 1, 18)); // NOI18N
        ClearPN.setForeground(new java.awt.Color(255, 102, 102));
        ClearPN.setText("CLEAR");
        ClearPN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ClearPNMouseClicked(evt);
            }
        });
        ClearPN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearPNActionPerformed(evt);
            }
        });

        LobPN.setFont(new java.awt.Font("Saysettha MX", 1, 18)); // NOI18N
        LobPN.setForeground(new java.awt.Color(255, 102, 102));
        LobPN.setText("ລົບ");
        LobPN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LobPNMouseClicked(evt);
            }
        });
        LobPN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LobPNActionPerformed(evt);
            }
        });

        TaTahlarngPN.setFont(new java.awt.Font("Saysettha MX", 1, 12)); // NOI18N
        TaTahlarngPN.setForeground(new java.awt.Color(255, 102, 102));
        TaTahlarngPN.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID ພະັນກງານ", "່ືຊ", "ລະັຫດ", "ເພດ"
            }
        ));
        TaTahlarngPN.setIntercellSpacing(new java.awt.Dimension(0, 0));
        TaTahlarngPN.setRowHeight(25);
        TaTahlarngPN.setSelectionBackground(new java.awt.Color(255, 102, 102));
        TaTahlarngPN.setSelectionForeground(new java.awt.Color(255, 102, 102));
        TaTahlarngPN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TaTahlarngPNMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TaTahlarngPN);

        jLabel8.setFont(new java.awt.Font("Saysettha MX", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("ເພດ:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(LahutPhanukngarn, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(SuePhanukngarn, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(IDPhanukngarn, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(BunthuekPN)
                            .addComponent(LobPN, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(42, 42, 42)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ClearPN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(KeaKhaiPN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(PhedPhanukngarn, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 514, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(IDPhanukngarn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PhedPhanukngarn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SuePhanukngarn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LahutPhanukngarn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(93, 93, 93)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(KeaKhaiPN)
                            .addComponent(BunthuekPN))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ClearPN)
                            .addComponent(LobPN))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21))))
        );

        jPanel2.setBackground(new java.awt.Color(204, 51, 0));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("x");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Saysettha MX", 1, 48)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ພະນັກງານຂາຍ");

        jLabel9.setFont(new java.awt.Font("Saysettha MX", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("ໝວດໝູ່");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Saysettha MX", 1, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("LOGIN");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Saysettha MX", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("ສີນຄ້າ");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(89, 89, 89)
                        .addComponent(jLabel10))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(94, 94, 94)
                        .addComponent(jLabel11)))
                .addGap(29, 29, 29)
                .addComponent(jLabel2)
                .addGap(252, 252, 252)
                .addComponent(jLabel1)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addContainerGap(26, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void SuePhanukngarnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SuePhanukngarnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SuePhanukngarnActionPerformed

    private void LahutPhanukngarnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LahutPhanukngarnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LahutPhanukngarnActionPerformed

    private void PhedPhanukngarnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PhedPhanukngarnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PhedPhanukngarnActionPerformed

    private void ClearPNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearPNActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ClearPNActionPerformed

    private void LobPNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LobPNActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LobPNActionPerformed

    private void BunthuekPNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BunthuekPNMouseClicked
        // TODO add your handling code here:
        if(IDPhanukngarn.getText().isEmpty()|| SuePhanukngarn.getText().isEmpty()|| LahutPhanukngarn.getText().isEmpty())
        {
          JOptionPane.showMessageDialog(this, "Missing Information");  
        }  
        else{
        try {
            Con = DriverManager.getConnection("jdbc:derby://localhost:1527/JokerGunShop","User1","1234");
            PreparedStatement Bunthuek = Con.prepareStatement("insert into PhanukngarnTb values(?,?,?,?)");
                    Bunthuek.setInt(1, Integer.valueOf(IDPhanukngarn.getText()));
                    Bunthuek.setString(2, SuePhanukngarn.getText());
                    Bunthuek.setString(3, LahutPhanukngarn.getText());
                    Bunthuek.setString(4, PhedPhanukngarn.getSelectedItem().toString());  
                    int row = Bunthuek.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Phanukngarn Added Successfully");
                    Con.close();
                    SelectPhanukngarnkhaiy();
                    }catch (Exception ex) {
                        ex.printStackTrace();
                        
        }
       }
    }//GEN-LAST:event_BunthuekPNMouseClicked

    private void TaTahlarngPNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TaTahlarngPNMouseClicked
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel)TaTahlarngPN.getModel();
        int Myindex = TaTahlarngPN.getSelectedRow();
        IDPhanukngarn.setText(model.getValueAt(Myindex, 0).toString());
        SuePhanukngarn.setText(model.getValueAt(Myindex, 1).toString());
        LahutPhanukngarn.setText(model.getValueAt(Myindex, 2).toString());
    }//GEN-LAST:event_TaTahlarngPNMouseClicked

    private void ClearPNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ClearPNMouseClicked
        // TODO add your handling code here:
        IDPhanukngarn.setText("");
        SuePhanukngarn.setText("");
        LahutPhanukngarn.setText("");
    }//GEN-LAST:event_ClearPNMouseClicked

    private void LobPNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LobPNMouseClicked
        // TODO add your handling code here:
        if(IDPhanukngarn.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(this, "Enter The Phanukngarnkhaiy to be Deleted");
        }
        else{
            try{
                 Con = DriverManager.getConnection("jdbc:derby://localhost:1527/JokerGunShop","User1","1234");
                 String IDP = IDPhanukngarn.getText();
                 String Query = "Delete from User1.PhanukngarnTb where IDPhanukngarn="+IDP;
                 Statement Add = Con.createStatement();
                 Add.executeUpdate(Query);
                 SelectPhanukngarnkhaiy();
                 JOptionPane.showMessageDialog(this, "Phanukngarnkhaiy Deleted Successfully");
            }catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }
    }//GEN-LAST:event_LobPNMouseClicked

    private void KeaKhaiPNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_KeaKhaiPNMouseClicked
        // TODO add your handling code here:
        if(IDPhanukngarn.getText().isEmpty()||SuePhanukngarn.getText().isEmpty()||LahutPhanukngarn.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(this, "Missing Information");
        }
        else
        {
            try{
                Con = DriverManager.getConnection("jdbc:derby://localhost:1527/JokerGunShop","User1","1234");
                String Query ="Update User1.PhanukngarnTb set SuePhanukngarn='"+SuePhanukngarn.getText()+"'"+",LahutPhanukngarn='"+LahutPhanukngarn.getText()+"'"+",PhedPhanukngarn='"+PhedPhanukngarn.getSelectedItem()+"'"+"where IDPhanukngarn="+IDPhanukngarn.getText();
                Statement Add = Con.createStatement();
                Add.executeUpdate(Query);
                JOptionPane.showMessageDialog(this, "Phanukngarnkhaiy Updated");
                SelectPhanukngarnkhaiy();
            }catch(SQLException ex)
            {
                ex.printStackTrace();
            }    
        }
    }//GEN-LAST:event_KeaKhaiPNMouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
        new muadmu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        // TODO add your handling code here:
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
        new product().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel10MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Phanukngarnkhaiy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Phanukngarnkhaiy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Phanukngarnkhaiy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Phanukngarnkhaiy.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Phanukngarnkhaiy().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BunthuekPN;
    private javax.swing.JButton ClearPN;
    private javax.swing.JTextField IDPhanukngarn;
    private javax.swing.JButton KeaKhaiPN;
    private javax.swing.JTextField LahutPhanukngarn;
    private javax.swing.JButton LobPN;
    private javax.swing.JComboBox<String> PhedPhanukngarn;
    private javax.swing.JTextField SuePhanukngarn;
    private javax.swing.JTable TaTahlarngPN;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
